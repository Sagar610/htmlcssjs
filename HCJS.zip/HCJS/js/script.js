// JavaScript code in script.js

// Function to load and display content
function loadContent(page) {
    const contentContainer = document.querySelector('.content');
    const xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
            contentContainer.innerHTML = this.responseText;
        }
    };

    xhttp.open('GET', page, true);
    xhttp.send();
}

// Add click event listeners to the navigation links
document.querySelectorAll('.navbar ul li a').forEach(link => {
    link.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default link behavior
        const page = this.getAttribute('href');
        loadContent(page);
    });
});
